import { Settings } from 'lucide-react'

export default function Settings() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <p className="mt-1 text-sm text-gray-600">
          Configure POS terminal settings
        </p>
      </div>

      <div className="pos-card">
        <div className="p-6">
          <p className="text-gray-500 text-center py-8">Settings interface coming soon...</p>
        </div>
      </div>
    </div>
  )
}