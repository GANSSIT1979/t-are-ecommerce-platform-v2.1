import { z } from 'zod';

export interface PaymentRequest {
  orderId: string;
  amount: number;
  paymentMethod: 'credit_card' | 'bank_transfer' | 'ewallet';
  customerInfo: {
    name: string;
    email: string;
    phone?: string;
  };
}

export interface PaymentResponse {
  id: string;
  orderId: string;
  amount: number;
  fee: number;
  totalAmount: number;
  status: 'pending' | 'processing' | 'success' | 'failed' | 'cancelled';
  transactionId?: string;
  errorMessage?: string;
  auditRef: string;
}

export interface AllBankWebhookPayload {
  transaction_id: string;
  order_id: string;
  amount: number;
  fee: number;
  status: 'success' | 'failed';
  timestamp: string;
  signature: string;
}

const PaymentRequestSchema = z.object({
  orderId: z.string(),
  amount: z.number().positive(),
  paymentMethod: z.enum(['credit_card', 'bank_transfer', 'ewallet']),
  customerInfo: z.object({
    name: z.string(),
    email: z.string().email(),
    phone: z.string().optional(),
  }),
});

export class PaymentService {
  private feeBps: number;

  constructor(feeBps: number = 150) {
    this.feeBps = feeBps;
  }

  calculateFee(amount: number): number {
    return Math.round((amount * this.feeBps) / 10000);
  }

  async processPayment(request: PaymentRequest): Promise<PaymentResponse> {
    const validated = PaymentRequestSchema.parse(request);
    const fee = this.calculateFee(validated.amount);
    const totalAmount = validated.amount + fee;

    try {
      // Simulate AllBank API call
      const allBankResponse = await this.callAllBankAPI({
        orderId: validated.orderId,
        amount: validated.amount,
        fee,
        totalAmount,
        paymentMethod: validated.paymentMethod,
        customerInfo: validated.customerInfo,
      });

      return {
        id: `pay_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        orderId: validated.orderId,
        amount: validated.amount,
        fee,
        totalAmount,
        status: allBankResponse.success ? 'success' : 'failed',
        transactionId: allBankResponse.transactionId,
        errorMessage: allBankResponse.errorMessage,
        auditRef: this.generateAuditRef(),
      };
    } catch (error) {
      return {
        id: `pay_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        orderId: validated.orderId,
        amount: validated.amount,
        fee,
        totalAmount,
        status: 'failed',
        errorMessage: error instanceof Error ? error.message : 'Unknown error',
        auditRef: this.generateAuditRef(),
      };
    }
  }

  async processWebhook(payload: AllBankWebhookPayload): Promise<boolean> {
    // Verify webhook signature
    if (!this.verifyWebhookSignature(payload)) {
      throw new Error('Invalid webhook signature');
    }

    // Process the webhook and update payment status
    // This would typically update the database and trigger business logic
    console.log(`Processing webhook for transaction ${payload.transaction_id}`);
    console.log(`Order ${payload.order_id} payment ${payload.status}`);

    return true;
  }

  private async callAllBankAPI(params: any): Promise<{ success: boolean; transactionId?: string; errorMessage?: string }> {
    // Simulate API call to AllBank
    await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate network delay

    // Simulate random success/failure for demo
    const isSuccess = Math.random() > 0.1; // 90% success rate

    if (isSuccess) {
      return {
        success: true,
        transactionId: `allbank_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      };
    } else {
      return {
        success: false,
        errorMessage: 'Payment processing failed',
      };
    }
  }

  private verifyWebhookSignature(payload: AllBankWebhookPayload): boolean {
    // In production, this would verify the actual signature
    // For demo purposes, we'll just check if required fields exist
    return !!(payload.transaction_id && payload.order_id && payload.signature);
  }

  private generateAuditRef(): string {
    return `trace-${Date.now()}-${Math.random().toString(36).substr(2, 8)}`;
  }

  async refundPayment(paymentId: string, amount?: number): Promise<PaymentResponse> {
    // Implement refund logic
    return {
      id: `ref_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      orderId: '',
      amount: amount || 0,
      fee: 0,
      totalAmount: amount || 0,
      status: 'pending',
      auditRef: this.generateAuditRef(),
    };
  }

  async getPaymentStatus(paymentId: string): Promise<PaymentResponse | null> {
    // Implement status check logic
    return null;
  }
}