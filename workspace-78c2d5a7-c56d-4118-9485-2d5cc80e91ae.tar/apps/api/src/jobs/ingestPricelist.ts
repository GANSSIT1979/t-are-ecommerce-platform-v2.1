import { parse } from 'csv-parse/sync';
import fs from 'node:fs';
import xlsx from 'xlsx';
import { cleanseNumber, normalizeHeader } from '../utils/csv';

const SYNONYMS: Record<string,string[]> = {
  sku_code: ['Itemcode','Item Code','SKU Code','Code'],
  sku_name: ['Local Descriptions','Description','Item Description'],
  uom_piece_per_case: ['Item per Case','Items Per Case','Item per Case (pcs)'],
  price_piece: ['Item Price','Piece Price','Unit Price','Item/Piece Price'],
  price_inner: ['Inner Case Price','Inner Price','Inner Case  Price'],
  price_case: ['Case Price','Case  Price'],
  srp: ['SRP','Suggested Retail Price'],
  status: ['SKU status in Order Pad (as of today)','SKU status in Order Pad','SKU Status','Status'],
  sku_type: ['SKU Type','Type'],
};

function readAny(path: string): { rows: Record<string,any>[] } {
  if (path.endsWith('.xlsx') || path.endsWith('.xls')) {
    const wb = xlsx.readFile(path, { cellDates: false });
    const ws = wb.Sheets[wb.SheetNames[0]];
    const json = xlsx.utils.sheet_to_json(ws, { raw: false });
    return { rows: json as any[] };
  }
  const csv = fs.readFileSync(path, 'utf8');
  const records = parse(csv, { columns: true, skip_empty_lines: true });
  return { rows: records };
}

export function autoMap(row: Record<string, any>) {
  const cols = Object.fromEntries(Object.keys(row).map((k) => [normalizeHeader(k), k]));
  const get = (logical: string) => {
    const cands = SYNONYMS[logical] || [];
    for (const c of cands) {
      const n = normalizeHeader(c);
      if (cols[n]) return row[cols[n]];
    }
    return undefined;
  };
  const mapped = {
    sku_code: get('sku_code'),
    sku_name: get('sku_name'),
    uom_piece_per_case: cleanseNumber(get('uom_piece_per_case')),
    price_piece: cleanseNumber(get('price_piece')),
    price_inner: cleanseNumber(get('price_inner')),
    price_case: cleanseNumber(get('price_case')),
    srp: cleanseNumber(get('srp')),
    status: get('status'),
    sku_type: get('sku_type'),
  };
  // collect extras
  const known = new Set(Object.values(SYNONYMS).flat().map(normalizeHeader));
  const extras: Record<string, any> = {};
  for (const [key, val] of Object.entries(row)) {
    const nk = normalizeHeader(key);
    if (!known.has(nk)) extras[key] = val;
  }
  return { mapped, extras };
}

export async function ingestPricelist(path: string, opts: { dryRun?: boolean } = {}) {
  const { rows } = readAny(path);
  const diff: any[] = [];
  const warnings: string[] = [];

  for (const r of rows) {
    const { mapped, extras } = autoMap(r);
    if (mapped.srp && mapped.price_piece && mapped.srp < mapped.price_piece) {
      warnings.push(`SRP < base per-piece for ${mapped.sku_code}`);
    }
    diff.push({ upsert: { ...mapped, extras } });
  }

  // TODO: upsert into skus + sku_prices (effective dating) using Drizzle
  if (opts.dryRun) return { count: diff.length, warnings, applied: false };
  return { count: diff.length, warnings, applied: true };
}