import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import Pricing from './pages/Pricing'
import Orders from './pages/Orders'
import Payments from './pages/Payments'
import Settlements from './pages/Settlements'
import Ingestion from './pages/Ingestion'
import Support from './pages/Support'

const queryClient = new QueryClient()

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/pricing" element={<Pricing />} />
            <Route path="/orders" element={<Orders />} />
            <Route path="/payments" element={<Payments />} />
            <Route path="/settlements" element={<Settlements />} />
            <Route path="/ingestion" element={<Ingestion />} />
            <Route path="/support" element={<Support />} />
          </Routes>
        </Layout>
      </Router>
    </QueryClientProvider>
  )
}

export default App