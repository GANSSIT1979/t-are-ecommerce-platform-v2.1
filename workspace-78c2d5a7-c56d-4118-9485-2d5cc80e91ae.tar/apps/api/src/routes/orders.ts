import { FastifyInstance } from 'fastify';
import { z } from 'zod';

export default async function ordersRoutes(app: FastifyInstance) {
  app.post('/orders', async (req, reply) => {
    const body = z.object({ items: z.array(z.object({ sku_id: z.string(), qty: z.number().int().positive(), uom: z.enum(['piece','inner','case']) })) }).parse(req.body);
    // TODO: write order + lines, emit audit
    return reply.code(201).send({ id: `ord_${Date.now()}`, status: 'Pending', audit_ref: `trace-${Date.now()}` });
  });

  app.post('/orders/:id/pay', async (req, reply) => {
    const { id } = req.params as any;
    // TODO: capture via AllBank, write transactions & ledger (1.5% fee mirrored)
    return reply.send({ id, payment: 'captured', audit_ref: `trace-${Date.now()}` });
  });

  app.post('/orders/:id/forward', async (req, reply) => {
    const { id } = req.params as any;
    // TODO: forward to JR&R; enqueue dispatch workflow
    return reply.send({ id, forwarded: true, audit_ref: `trace-${Date.now()}` });
  });

  app.post('/settlements/:order_id', async (req, reply) => {
    const { order_id } = req.params as any;
    // TODO: post double-entry ledger; validate debits==credits
    return reply.send({ order_id, settled: true, audit_ref: `trace-${Date.now()}` });
  });
}