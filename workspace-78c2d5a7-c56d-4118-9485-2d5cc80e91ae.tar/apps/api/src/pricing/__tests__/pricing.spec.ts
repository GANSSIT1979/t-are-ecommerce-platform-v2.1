import { describe, it, expect } from '@jest/globals';
import { quotePricing } from '../engine';

type UOM = 'piece' | 'inner' | 'case';
const EPS = 1e-6;
const approx = (a:number,b:number,eps=EPS)=>Math.abs(a-b)<=eps;

const SPLITS = { tare: 0.20, ismc: 0.20, cda: 0.14, cashlink: 0.45, ecommerce_software: 0.01 };
const sumSplits = Object.values(SPLITS).reduce((a,b)=>a+b,0);

describe('Pricing Engine — Split & Rebate Validation', () => {
  it('split percentages must sum to 1.0', () => {
    expect(approx(sumSplits, 1.0)).toBe(true);
  });

  it('returns correct split keys & values', async () => {
    const r = await quotePricing({ skuId: 'JRNR-12345', quantity: 1, uom: 'case', rebate: 0.05 });
    expect(r.splits).toMatchObject(SPLITS);
    const total = Object.values(r.splits).reduce((a:number,b:number)=>a+b,0);
    expect(approx(total, 1.0)).toBe(true);
  });

  it.each([{rebate:0.03},{rebate:0.04},{rebate:0.05}])('cogs & gmp for rebate=%p', async ({rebate})=>{
    const r = await quotePricing({ skuId: 'JRNR-12345', quantity: 10, uom: 'case', rebate });
    const expectedPricePerPiece = 480/24;
    const expectedEffectiveCogs = expectedPricePerPiece*(1-rebate);
    const expectedGmp = 25-expectedEffectiveCogs;
    expect(approx(r.price_per_piece, expectedPricePerPiece)).toBe(true);
    expect(approx(r.effective_cogs, expectedEffectiveCogs)).toBe(true);
    expect(approx(r.gmp, expectedGmp)).toBe(true);
    const splitSum = Object.values(r.split_amounts).reduce((a,b)=>a+b,0);
    expect(approx(splitSum, r.gmp)).toBe(true);
  });

  it('UOM parity (piece vs case)', async () => {
    const piece = await quotePricing({ skuId: 'JRNR-12345', quantity: 24, uom: 'piece', rebate: 0.05 });
    const kase  = await quotePricing({ skuId: 'JRNR-12345', quantity: 1,  uom: 'case',  rebate: 0.05 });
    expect(approx(piece.price_per_piece, kase.price_per_piece)).toBe(true);
  });

  it('selects promo vs base fixtures', async () => {
    const promo = await quotePricing({ skuId: 'PROMO-SKU-1', quantity: 1, uom: 'case', rebate: 0.05 });
    const base  = await quotePricing({ skuId: 'BASE-SKU-1',  quantity: 1, uom: 'case', rebate: 0.05 });
    expect(promo.status).toBe('Promo');
    expect(base.status).toBe('Base');
    expect(promo.price_case).not.toBe(base.price_case);
  });

  it('flags SRP guardrail', async () => {
    const r = await quotePricing({ skuId: 'GUARDRAIL-SKU', quantity: 1, uom: 'case', rebate: 0.03 });
    expect(r.warnings?.join(' ')).toMatch(/SRP/i);
  });
});