import { FastifyInstance } from 'fastify';
export async function initMetrics(app: FastifyInstance) {
  app.decorate('metrics', {
    reqCount: 0,
  });
  app.addHook('onRequest', async () => {
    // increment counters / start timers here; integrate prom-client later
  });
}