# T-ARE E‑Commerce Platform V2.0

Multi-tenant commerce stack with RBAC, pricing, payments, logistics, finance (double-entry), observability, and compliance.

## Quickstart
1. `cp .env.example .env`
2. `docker compose up -d`
3. `pnpm i`
4. `pnpm -C apps/api dev`

## Key Endpoints
- `GET /pricing/sku/:id?quantity=10&uom=case&rebate=0.05`
- `POST /jobs/ingest-pricelist { path, dryRun }`
- `POST /orders` → `POST /orders/:id/pay` → `POST /orders/:id/forward` → `POST /settlements/:order_id`
- `POST /support/quote { term, volume, applyTRA?, promoDealPct? }`

## Tests
`pnpm -C apps/api test`

## Architecture

### Monorepo Structure
```
TARE-V2/
├─ package.json
├─ pnpm-workspace.yaml
├─ .env.example
├─ docker-compose.yml
├─ README.md
├─ .github/
│  └─ workflows/ci.yml
├─ apps/
│  ├─ api/
│  │  ├─ package.json
│  │  ├─ tsconfig.json
│  │  └─ src/
│  │     ├─ server.ts
│  │     ├─ routes/
│  │     │  ├─ pricing.ts
│  │     │  ├─ support.ts
│  │     │  ├─ orders.ts
│  │     │  └─ jobs.ts
│  │     ├─ pricing/
│  │     │  ├─ engine.ts
│  │     │  └─ __tests__/pricing.spec.ts
│  │     ├─ jobs/ingestPricelist.ts
│  │     ├─ middleware/
│  │     │  ├─ tenant.ts
│  │     │  └─ idempotency.ts
│  │     ├─ db/
│  │     │  ├─ client.ts
│  │     │  └─ schema.ts
│  │     ├─ observability/
│  │     │  ├─ otel.ts
│  │     │  └─ metrics.ts
│  │     └─ utils/
│  │        └─ csv.ts
│  ├─ admin/ (vite react-ts, tailwind, react-query)  — scaffold only
│  └─ pos/   (vite react-ts pwa)                     — scaffold only
├─ packages/
│  ├─ types/
│  │  └─ index.ts
│  └─ config/
│     └─ index.ts
└─ keycloak/
   └─ tare-realm.json
```

### Core Features

#### 1. Pricing Engine
- New split model: T‑ARE 20% | ISMC 20% | CDA 14% | Cashlink 45% | E‑Commerce 1%
- Support for multiple UOMs (piece, inner, case)
- Rebate calculations (3-5%)
- SRP guardrail warnings
- Comprehensive test coverage

#### 2. Multi-Tenant Architecture
- Hierarchical tenant structure: Org → Coop → Branch → Store
- RBAC with Keycloak integration
- Tenant-scoped database operations
- Audit logging with trace references

#### 3. Data Ingestion
- CSV/XLSX file processing
- Fuzzy header mapping with synonyms
- Currency sanitization
- Dry-run support
- SRP validation warnings

#### 4. Order Management
- Full order lifecycle management
- Payment processing with AllBank integration
- Double-entry ledger accounting
- Settlement processing
- Audit trail for all operations

#### 5. Support Calculator
- JR&R → T‑ARE integration
- Term-based calculations (POST, COD, 15D, 30D)
- Multiple support types (Regular Discount, Loyalty Incentive, TRA/BO, Quota Incentive)
- Promo deal support
- Booking categorization

#### 6. Observability
- OpenTelemetry integration
- Prometheus metrics
- Request tracing
- Audit logging
- Performance monitoring

### Technology Stack

#### Backend
- **Framework**: Fastify (Node.js)
- **Database**: PostgreSQL with Drizzle ORM
- **Cache**: Redis
- **Message Queue**: NATS
- **Authentication**: Keycloak
- **File Storage**: MinIO (S3-compatible)
- **Testing**: Jest
- **Observability**: OpenTelemetry, Prometheus

#### Infrastructure
- **Containerization**: Docker Compose
- **CI/CD**: GitHub Actions
- **Package Manager**: pnpm
- **TypeScript**: Strict mode enabled

### Database Schema

The platform uses a comprehensive database schema with the following key models:

#### Directory Structure
- **Orgs**: Top-level organizations
- **Coops**: Cooperatives within organizations
- **Branches**: Branches within cooperatives
- **Stores**: Individual stores

#### Catalog Management
- **SKUs**: Product catalog with status tracking
- **SKU Prices**: Time-based pricing with effective dating
- **SKU Status History**: Status change tracking

#### Order & Payment Processing
- **Orders**: Complete order management with tenant scoping
- **Order Lines**: Individual order items
- **Payments**: Payment processing with fee tracking
- **Transactions**: Raw transaction data
- **Ledger Entries**: Double-entry accounting

#### Logistics
- **Dispatches**: Order dispatch tracking
- **ASN**: Advanced Shipping Notices
- **POD**: Proof of Delivery
- **GRN**: Goods Receipt Notes

### API Documentation

#### Pricing API
```bash
GET /pricing/sku/{skuId}?quantity={qty}&uom={uom}&rebate={rebate}
```

**Parameters:**
- `skuId`: Product SKU identifier
- `quantity`: Order quantity
- `uom`: Unit of measure (piece, inner, case)
- `rebate`: Rebate percentage (0.03-0.05)

**Response:**
```json
{
  "sku_id": "JRNR-12345",
  "status": "Promo",
  "uom": "case",
  "quantity": 10,
  "srp": 25,
  "price_case": 480,
  "uom_piece_per_case": 24,
  "price_per_piece": 20,
  "rebate": 0.05,
  "effective_cogs": 19,
  "gmp": 6,
  "splits": {
    "tare": 0.20,
    "ismc": 0.20,
    "cda": 0.14,
    "cashlink": 0.45,
    "ecommerce_software": 0.01
  },
  "split_amounts": {
    "tare": 1.2,
    "ismc": 1.2,
    "cda": 0.84,
    "cashlink": 2.7,
    "ecommerce_software": 0.06
  },
  "audit_ref": "trace-1234567890-abc123"
}
```

#### Ingestion API
```bash
POST /jobs/ingest-pricelist
```

**Request Body:**
```json
{
  "path": "/path/to/pricelist.csv",
  "dryRun": false
}
```

**Response:**
```json
{
  "count": 150,
  "warnings": ["SRP < base per-piece for SKU-123"],
  "applied": true
}
```

#### Orders API
```bash
POST /orders
POST /orders/{id}/pay
POST /orders/{id}/forward
POST /settlements/{order_id}
```

#### Support Calculator API
```bash
POST /support/quote
```

**Request Body:**
```json
{
  "term": "POST",
  "volume": 10000,
  "applyTRA": true,
  "promoDealPct": 0.05
}
```

### Development

#### Setting Up Development Environment
1. Clone the repository
2. Copy `.env.example` to `.env` and configure environment variables
3. Start infrastructure services: `docker compose up -d`
4. Install dependencies: `pnpm i`
5. Start API server: `pnpm -C apps/api dev`
6. Run tests: `pnpm -C apps/api test`

#### Running Tests
The platform includes comprehensive test coverage for the pricing engine and other core components:

```bash
# Run all tests
pnpm -C apps/api test

# Run tests with coverage
pnpm -C apps/api test -- --coverage
```

#### Code Quality
```bash
# Lint code
pnpm -C apps/api lint

# Type checking
pnpm -C apps/api typecheck
```

### Deployment

#### Production Considerations
- Use PostgreSQL instead of SQLite for production
- Configure proper Redis persistence
- Set up proper Keycloak production instance
- Configure SSL/TLS for all services
- Set up proper monitoring and alerting
- Implement proper backup strategies

#### Environment Variables
Key environment variables that need to be configured for production:

```bash
# Database
DATABASE_URL=postgres://user:pass@host:5432/tare

# Redis
REDIS_URL=redis://host:6379

# NATS
NATS_URL=nats://host:4222

# S3 Storage
S3_ENDPOINT=https://s3.example.com
S3_ACCESS_KEY=your-access-key
S3_SECRET_KEY=your-secret-key
S3_BUCKET=tare-artifacts

# Keycloak
KEYCLOAK_ISSUER=https://auth.example.com/realms/tare
KEYCLOAK_AUDIENCE=tare-api
JWT_JWKS_URI=https://auth.example.com/realms/tare/protocol/openid-connect/certs

# Observability
OTEL_EXPORTER_OTLP_ENDPOINT=http://otel-collector:4317

# Payment Processing
ALLBANK_WEBHOOK_IP_ALLOWLIST=192.168.1.0/24
ALLBANK_FEE_BPS=150
```

### Security Features

#### Authentication & Authorization
- JWT-based authentication with Keycloak
- Role-based access control (RBAC)
- Tenant-scoped permissions
- API key support for service accounts

#### Data Protection
- Input validation with Zod
- SQL injection prevention with ORM
- XSS protection
- CSRF protection
- Secure headers

#### Audit & Compliance
- Immutable audit trails
- Request tracing
- Activity logging
- Compliance reporting

### Monitoring & Observability

#### Metrics Collection
- Request metrics
- Database query performance
- Cache hit rates
- Business metrics (orders, payments, etc.)

#### Logging
- Structured logging
- Request correlation IDs
- Error tracking
- Performance monitoring

#### Alerting
- Error rate alerts
- Performance degradation alerts
- Business metric alerts
- Infrastructure health alerts

### Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Run the test suite
6. Submit a pull request

### License

This project is licensed under the MIT License.