import Fastify from 'fastify';
import pricingRoutes from './routes/pricing';
import supportRoutes from './routes/support';
import jobsRoutes from './routes/jobs';
import ordersRoutes from './routes/orders';
import paymentsRoutes from './routes/payments';
import settlementsRoutes from './routes/settlements';
import { tenantPlugin } from './middleware/tenant';
import { idempotencyPlugin } from './middleware/idempotency';
import { initMetrics } from './observability/metrics';

const app = Fastify({ logger: true });

await initMetrics(app);
await app.register(tenantPlugin);
await app.register(idempotencyPlugin);

await app.register(pricingRoutes);
await app.register(supportRoutes);
await app.register(jobsRoutes);
await app.register(ordersRoutes);
await app.register(paymentsRoutes);
await app.register(settlementsRoutes);

const port = Number(process.env.PORT || 3000);
app.listen({ port, host: '0.0.0.0' }).catch((e) => {
  app.log.error(e, 'Failed to start');
  process.exit(1);
});