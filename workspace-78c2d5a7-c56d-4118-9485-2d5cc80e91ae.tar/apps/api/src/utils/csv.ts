export function cleanseNumber(s: any): number | null {
  if (s === null || s === undefined) return null;
  const v = String(s).replace(/[,₱]/g, '').trim();
  if (!v) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

export function normalizeHeader(h: string) {
  return h.replace(/\n+/g,' ').replace(/\s+/g,' ').trim();
}