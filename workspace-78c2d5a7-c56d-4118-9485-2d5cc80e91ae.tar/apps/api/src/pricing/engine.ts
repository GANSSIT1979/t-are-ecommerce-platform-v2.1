export interface QuoteInput {
  skuId: string;
  quantity: number;
  uom: 'piece' | 'inner' | 'case';
  rebate: number; // 0.03 to 0.05
}

export interface QuoteResult {
  sku_id: string;
  status: 'Promo' | 'Base';
  uom: 'piece' | 'inner' | 'case';
  quantity: number;
  srp: number;
  price_case: number;
  uom_piece_per_case: number;
  price_per_piece: number;
  rebate: number;
  effective_cogs: number;
  gmp: number;
  splits: {
    tare: number; ismc: number; cda: number; cashlink: number; ecommerce_software: number;
  };
  split_amounts: {
    tare: number; ismc: number; cda: number; cashlink: number; ecommerce_software: number;
  };
  warnings?: string[];
  audit_ref: string;
}

const SPLITS = { tare: 0.20, ismc: 0.20, cda: 0.14, cashlink: 0.45, ecommerce_software: 0.01 } as const;

// minimal in-memory SKU fixture; replace with DB lookup
const SKUS: Record<string, any> = {
  'JRNR-12345': { status: 'Promo', srp: 25, price_case: 480, uom_piece_per_case: 24 },
  'PROMO-SKU-1': { status: 'Promo', srp: 25, price_case: 460, uom_piece_per_case: 24 },
  'BASE-SKU-1':  { status: 'Base',  srp: 25, price_case: 510, uom_piece_per_case: 24 },
  'GUARDRAIL-SKU': { status: 'Base', srp: 10, price_case: 480, uom_piece_per_case: 24 },
};

function auditRef() { return `trace-${Date.now()}-${Math.random().toString(36).slice(2,8)}`; }

export async function quotePricing(input: QuoteInput): Promise<QuoteResult> {
  const sku = SKUS[input.skuId];
  if (!sku) throw new Error('SKU not found');
  const status = sku.status as 'Promo' | 'Base';
  const srp = Number(sku.srp);
  const price_case = Number(sku.price_case);
  const ppc = Number(sku.uom_piece_per_case || 1);

  const price_per_piece = price_case / ppc;
  const effective_cogs = price_per_piece * (1 - input.rebate);
  const gmp = srp - effective_cogs;

  const warnings: string[] = [];
  if (srp < price_per_piece) warnings.push('SRP is less than base per-piece price');

  const split_amounts = {
    tare: gmp * SPLITS.tare,
    ismc: gmp * SPLITS.ismc,
    cda: gmp * SPLITS.cda,
    cashlink: gmp * SPLITS.cashlink,
    ecommerce_software: gmp * SPLITS.ecommerce_software,
  } as const;

  return {
    sku_id: input.skuId,
    status,
    uom: input.uom,
    quantity: input.quantity,
    srp,
    price_case,
    uom_piece_per_case: ppc,
    price_per_piece,
    rebate: input.rebate,
    effective_cogs,
    gmp,
    splits: SPLITS,
    split_amounts,
    warnings,
    audit_ref: auditRef(),
  };
}