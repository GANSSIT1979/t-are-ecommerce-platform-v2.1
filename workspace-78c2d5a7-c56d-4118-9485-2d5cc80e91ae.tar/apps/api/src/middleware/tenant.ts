import fp from 'fastify-plugin';
import { z } from 'zod';

const Claims = z.object({
  org_id: z.string(),
  coop_id: z.string().optional(),
  branch_id: z.string().optional(),
  store_id: z.string().optional(),
  role: z.string(),
  scopes: z.array(z.string()).optional(),
});

export const tenantPlugin = fp(async (app) => {
  app.decorateRequest('tenant', null);
  app.addHook('preHandler', async (req) => {
    // In production: verify Keycloak JWT via JWKS; here we accept x-tenant header for dev
    const raw = (req.headers['x-tenant'] as string) || '{}';
    let claims: any;
    try { claims = JSON.parse(raw); } catch { claims = {}; }
    const parsed = Claims.safeParse(claims);
    if (!parsed.success) throw app.httpErrors.unauthorized('Invalid tenant claims');
    // @ts-expect-error attach
    req.tenant = parsed.data;
  });
});

declare module 'fastify' {
  interface FastifyRequest { tenant: z.infer<typeof Claims> | null }
}