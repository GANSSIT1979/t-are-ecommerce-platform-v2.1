import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { SettlementService } from '../services/settlement';

const settlementService = new SettlementService();

export default async function settlementsRoutes(app: FastifyInstance) {
  // Process settlement
  app.post('/settlements', async (req, reply) => {
    const body = z.object({
      orderId: z.string(),
      settlementDate: z.string(),
      items: z.array(z.object({
        accountId: z.string(),
        debit: z.number().min(0),
        credit: z.number().min(0),
        description: z.string(),
        category: z.string(),
      })),
    }).parse(req.body);

    const result = await settlementService.processSettlement(body);
    
    return reply.header('x-audit-ref', result.auditRef).send(result);
  });

  // Generate settlement from order
  app.post('/settlements/generate/:orderId', async (req, reply) => {
    const { orderId } = req.params as any;
    const body = z.object({
      orderAmount: z.number().positive(),
      splits: z.object({
        tare: z.number(),
        ismc: z.number(),
        cda: z.number(),
        cashlink: z.number(),
        ecommerce_software: z.number(),
      }),
    }).parse(req.body);

    const settlementRequest = await settlementService.generateSettlementFromOrder(
      orderId,
      body.orderAmount,
      body.splits
    );

    return reply.send(settlementRequest);
  });

  // Get account balances
  app.get('/settlements/accounts', async (req, reply) => {
    const balances = await settlementService.getAccountBalances();
    return reply.send({ accounts: balances });
  });

  // Get settlement history
  app.get('/settlements/history', async (req, reply) => {
    const { orderId } = req.query as any;
    const history = await settlementService.getSettlementHistory(orderId);
    return reply.send({ settlements: history });
  });

  // Reconcile accounts
  app.post('/settlements/reconcile', async (req, reply) => {
    const result = await settlementService.reconcileAccounts();
    return reply.send(result);
  });

  // Get trial balance
  app.get('/settlements/trial-balance', async (req, reply) => {
    const trialBalance = await settlementService.getTrialBalance();
    return reply.send({ trialBalance });
  });

  // Get settlement details
  app.get('/settlements/:id', async (req, reply) => {
    const { id } = req.params as any;
    // In a real implementation, this would fetch from database
    return reply.code(404).send({ error: 'Settlement not found' });
  });

  // Validate settlement before processing
  app.post('/settlements/validate', async (req, reply) => {
    const body = z.object({
      items: z.array(z.object({
        accountId: z.string(),
        debit: z.number().min(0),
        credit: z.number().min(0),
        description: z.string(),
        category: z.string(),
      })),
    }).parse(req.body);

    try {
      // Simulate validation
      const totalDebit = body.items.reduce((sum, item) => sum + item.debit, 0);
      const totalCredit = body.items.reduce((sum, item) => sum + item.credit, 0);
      
      const isValid = totalDebit === totalCredit && body.items.length >= 2;
      
      return reply.send({
        isValid,
        totalDebit,
        totalCredit,
        isBalanced: totalDebit === totalCredit,
        errors: isValid ? [] : [
          totalDebit !== totalCredit ? 'Total debit must equal total credit' : '',
          body.items.length < 2 ? 'At least two entries required' : ''
        ].filter(Boolean),
      });
    } catch (error) {
      return reply.code(400).send({
        isValid: false,
        errors: [error instanceof Error ? error.message : 'Validation failed'],
      });
    }
  });

  // Get chart of accounts
  app.get('/settlements/chart-of-accounts', async (req, reply) => {
    const chartOfAccounts = [
      { id: 'CASH', name: 'Cash on Hand', type: 'Asset', category: 'Current Assets' },
      { id: 'BANK', name: 'Bank Account', type: 'Asset', category: 'Current Assets' },
      { id: 'AR_TARE', name: 'Accounts Receivable - T-ARE', type: 'Asset', category: 'Accounts Receivable' },
      { id: 'AR_ISMC', name: 'Accounts Receivable - ISMC', type: 'Asset', category: 'Accounts Receivable' },
      { id: 'AR_CDA', name: 'Accounts Receivable - CDA', type: 'Asset', category: 'Accounts Receivable' },
      { id: 'AR_CASHLINK', name: 'Accounts Receivable - Cashlink', type: 'Asset', category: 'Accounts Receivable' },
      { id: 'AR_EC', name: 'Accounts Receivable - E-Commerce', type: 'Asset', category: 'Accounts Receivable' },
      { id: 'REVENUE', name: 'Revenue', type: 'Equity', category: 'Revenue' },
      { id: 'FEES', name: 'Processing Fees', type: 'Expense', category: 'Operating Expenses' },
      { id: 'TAXES', name: 'Taxes Payable', type: 'Liability', category: 'Current Liabilities' },
    ];

    return reply.send({ chartOfAccounts });
  });
}