import { z } from 'zod';

export interface SettlementRequest {
  orderId: string;
  settlementDate: string;
  items: SettlementItem[];
}

export interface SettlementItem {
  accountId: string;
  debit: number;
  credit: number;
  description: string;
  category: string;
}

export interface SettlementResponse {
  id: string;
  orderId: string;
  settlementDate: string;
  status: 'pending' | 'processed' | 'failed';
  totalDebit: number;
  totalCredit: number;
  isBalanced: boolean;
  entries: LedgerEntry[];
  auditRef: string;
  errorMessage?: string;
}

export interface LedgerEntry {
  id: string;
  accountId: string;
  debit: number;
  credit: number;
  description: string;
  category: string;
  settlementId: string;
  createdAt: string;
}

export interface AccountBalance {
  accountId: string;
  accountName: string;
  currentBalance: number;
  currency: string;
}

const SettlementRequestSchema = z.object({
  orderId: z.string(),
  settlementDate: z.string(),
  items: z.array(z.object({
    accountId: z.string(),
    debit: z.number().min(0),
    credit: z.number().min(0),
    description: z.string(),
    category: z.string(),
  })),
});

export class SettlementService {
  private accounts: Map<string, AccountBalance> = new Map();

  constructor() {
    this.initializeAccounts();
  }

  private initializeAccounts() {
    // Initialize standard chart of accounts
    const standardAccounts = [
      { id: 'CASH', name: 'Cash on Hand', balance: 0 },
      { id: 'BANK', name: 'Bank Account', balance: 0 },
      { id: 'AR_TARE', name: 'Accounts Receivable - T-ARE', balance: 0 },
      { id: 'AR_ISMC', name: 'Accounts Receivable - ISMC', balance: 0 },
      { id: 'AR_CDA', name: 'Accounts Receivable - CDA', balance: 0 },
      { id: 'AR_CASHLINK', name: 'Accounts Receivable - Cashlink', balance: 0 },
      { id: 'AR_EC', name: 'Accounts Receivable - E-Commerce', balance: 0 },
      { id: 'REVENUE', name: 'Revenue', balance: 0 },
      { id: 'FEES', name: 'Processing Fees', balance: 0 },
      { id: 'TAXES', name: 'Taxes Payable', balance: 0 },
    ];

    standardAccounts.forEach(account => {
      this.accounts.set(account.id, {
        accountId: account.id,
        accountName: account.name,
        currentBalance: account.balance,
        currency: 'PHP',
      });
    });
  }

  async processSettlement(request: SettlementRequest): Promise<SettlementResponse> {
    const validated = SettlementRequestSchema.parse(request);
    
    try {
      // Validate double-entry accounting rules
      const validation = this.validateSettlement(validated.items);
      if (!validation.isValid) {
        throw new Error(validation.error);
      }

      // Generate ledger entries
      const entries = this.generateLedgerEntries(validated);
      
      // Update account balances
      await this.updateAccountBalances(entries);

      const totalDebit = entries.reduce((sum, entry) => sum + entry.debit, 0);
      const totalCredit = entries.reduce((sum, entry) => sum + entry.credit, 0);

      return {
        id: `set_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        orderId: validated.orderId,
        settlementDate: validated.settlementDate,
        status: 'processed',
        totalDebit,
        totalCredit,
        isBalanced: totalDebit === totalCredit,
        entries,
        auditRef: this.generateAuditRef(),
      };
    } catch (error) {
      return {
        id: `set_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        orderId: validated.orderId,
        settlementDate: validated.settlementDate,
        status: 'failed',
        totalDebit: 0,
        totalCredit: 0,
        isBalanced: false,
        entries: [],
        auditRef: this.generateAuditRef(),
        errorMessage: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  private validateSettlement(items: SettlementItem[]): { isValid: boolean; error?: string } {
    const totalDebit = items.reduce((sum, item) => sum + item.debit, 0);
    const totalCredit = items.reduce((sum, item) => sum + item.credit, 0);

    if (totalDebit !== totalCredit) {
      return {
        isValid: false,
        error: `Double-entry rule violated: Total debit (${totalDebit}) != Total credit (${totalCredit})`,
      };
    }

    if (items.length < 2) {
      return {
        isValid: false,
        error: 'At least two entries required for double-entry accounting',
      };
    }

    return { isValid: true };
  }

  private generateLedgerEntries(request: SettlementRequest): LedgerEntry[] {
    return request.items.map((item, index) => ({
      id: `entry_${Date.now()}_${index}_${Math.random().toString(36).substr(2, 6)}`,
      accountId: item.accountId,
      debit: item.debit,
      credit: item.credit,
      description: item.description,
      category: item.category,
      settlementId: '', // Will be set after settlement ID is generated
      createdAt: new Date().toISOString(),
    }));
  }

  private async updateAccountBalances(entries: LedgerEntry[]): Promise<void> {
    entries.forEach(entry => {
      const account = this.accounts.get(entry.accountId);
      if (account) {
        const netChange = entry.debit - entry.credit;
        account.currentBalance += netChange;
        this.accounts.set(entry.accountId, account);
      }
    });
  }

  async generateSettlementFromOrder(orderId: string, orderAmount: number, splits: any): Promise<SettlementRequest> {
    const settlementDate = new Date().toISOString().split('T')[0];
    
    const items: SettlementItem[] = [
      // Debit the revenue account
      {
        accountId: 'REVENUE',
        debit: orderAmount,
        credit: 0,
        description: `Revenue from order ${orderId}`,
        category: 'Revenue',
      },
      // Credit the split accounts
      {
        accountId: 'AR_TARE',
        debit: 0,
        credit: splits.tare || 0,
        description: `T-ARE share from order ${orderId}`,
        category: 'Revenue Share',
      },
      {
        accountId: 'AR_ISMC',
        debit: 0,
        credit: splits.ismc || 0,
        description: `ISMC share from order ${orderId}`,
        category: 'Revenue Share',
      },
      {
        accountId: 'AR_CDA',
        debit: 0,
        credit: splits.cda || 0,
        description: `CDA share from order ${orderId}`,
        category: 'Revenue Share',
      },
      {
        accountId: 'AR_CASHLINK',
        debit: 0,
        credit: splits.cashlink || 0,
        description: `Cashlink share from order ${orderId}`,
        category: 'Revenue Share',
      },
      {
        accountId: 'AR_EC',
        debit: 0,
        credit: splits.ecommerce_software || 0,
        description: `E-Commerce share from order ${orderId}`,
        category: 'Revenue Share',
      },
    ];

    return {
      orderId,
      settlementDate,
      items,
    };
  }

  async getAccountBalances(): Promise<AccountBalance[]> {
    return Array.from(this.accounts.values());
  }

  async getSettlementHistory(orderId?: string): Promise<SettlementResponse[]> {
    // In a real implementation, this would query the database
    // For demo purposes, return empty array
    return [];
  }

  async reconcileAccounts(): Promise<{ reconciled: boolean; discrepancies: string[] }> {
    const discrepancies: string[] = [];
    
    // Check for basic accounting rules
    const totalAssets = Array.from(this.accounts.values())
      .filter(acc => acc.accountId.startsWith('AR_') || ['CASH', 'BANK'].includes(acc.accountId))
      .reduce((sum, acc) => sum + acc.currentBalance, 0);
    
    const totalLiabilities = Array.from(this.accounts.values())
      .filter(acc => ['TAXES'].includes(acc.accountId))
      .reduce((sum, acc) => sum + acc.currentBalance, 0);
    
    const totalEquity = Array.from(this.accounts.values())
      .filter(acc => ['REVENUE', 'FEES'].includes(acc.accountId))
      .reduce((sum, acc) => sum + acc.currentBalance, 0);

    if (Math.abs(totalAssets - (totalLiabilities + totalEquity)) > 0.01) {
      discrepancies.push('Balance sheet does not balance');
    }

    return {
      reconciled: discrepancies.length === 0,
      discrepancies,
    };
  }

  private generateAuditRef(): string {
    return `trace-${Date.now()}-${Math.random().toString(36).substr(2, 8)}`;
  }

  async getTrialBalance(): Promise<{ accountId: string; accountName: string; debit: number; credit: number }[]> {
    return Array.from(this.accounts.values()).map(account => ({
      accountId: account.accountId,
      accountName: account.accountName,
      debit: account.currentBalance > 0 ? account.currentBalance : 0,
      credit: account.currentBalance < 0 ? Math.abs(account.currentBalance) : 0,
    }));
  }
}