import { FastifyInstance } from 'fastify';
import { z } from 'zod';

export type Term = 'POST' | 'COD' | '15D' | '30D';
const PROGRAM_V2025_1 = {
  REGULAR_DISCOUNT: { POST: 0.04, COD: 0.03, '15D': 0.04, '30D': 0.02 },
  LOYALTY_INCENTIVE: 0.04,
  TRA_BO: 0.0025,
  QUOTA_INCENTIVE: { POST: 0.02, COD: 0.015, '15D': 0.02, '30D': 0.01 },
} as const;

function computeSupport(term: Term, volume: number, applyTRA = true, promoDealPct = 0) {
  const pct = (n:number)=>Number(n.toFixed(6));
  const amt = (n:number)=>Math.round(n*100)/100;
  const clamp=(n:number,min:number,max:number)=>Math.min(max,Math.max(min,n));
  const reg = pct(PROGRAM_V2025_1.REGULAR_DISCOUNT[term]);
  const loy = pct(PROGRAM_V2025_1.LOYALTY_INCENTIVE);
  const tra = pct(applyTRA ? PROGRAM_V2025_1.TRA_BO : 0);
  const quota = pct(PROGRAM_V2025_1.QUOTA_INCENTIVE[term]);
  const items = [
    { label: 'Regular Discount', percent: reg, amount: amt(volume*reg), booking: 'System' },
    { label: 'Loyalty Incentive (DPSP)', percent: loy, amount: amt(volume*loy), booking: 'CM' },
    { label: 'TRA / BO Allowance', percent: tra, amount: amt(volume*tra), booking: 'System' },
    { label: 'Quota Incentive', percent: quota, amount: amt(volume*quota), booking: 'CM' },
  ];
  const basePct = pct(reg+loy+tra+quota);
  const promo = pct(clamp(promoDealPct||0,0,0.50));
  if (promo>0) items.push({ label: 'Monthly Promo Deal', percent: promo, amount: amt(volume*promo), booking: 'CM' });
  const grandPct = pct(basePct+promo);
  const grandAmt = amt(volume*grandPct);
  return { term, volume, items, totalSupportPct: basePct, grandTotalPct: grandPct, grandTotalAmount: grandAmt };
}

export default async function supportRoutes(app: FastifyInstance) {
  const S = z.object({ term: z.enum(['POST','COD','15D','30D']), volume: z.number().positive(), applyTRA: z.boolean().optional(), promoDealPct: z.number().min(0).max(0.5).optional() });
  app.post('/support/quote', async (req, reply) => {
    const b = S.parse(req.body);
    const res = computeSupport(b.term as Term, b.volume, b.applyTRA ?? true, b.promoDealPct ?? 0);
    return reply.send(res);
  });
}