export const config = {
  database: {
    url: process.env.DATABASE_URL || 'sqlite:./tare.db',
  },
  redis: {
    url: process.env.REDIS_URL || 'redis://localhost:6379',
  },
  nats: {
    url: process.env.NATS_URL || 'nats://localhost:4222',
  },
  s3: {
    endpoint: process.env.S3_ENDPOINT || 'http://localhost:9000',
    accessKey: process.env.S3_ACCESS_KEY || 'minioadmin',
    secretKey: process.env.S3_SECRET_KEY || 'minioadmin',
    bucket: process.env.S3_BUCKET || 'tare-artifacts',
  },
  keycloak: {
    issuer: process.env.KEYCLOAK_ISSUER || 'http://localhost:8080/realms/tare',
    audience: process.env.KEYCLOAK_AUDIENCE || 'tare-api',
    jwksUri: process.env.JWT_JWKS_URI || 'http://localhost:8080/realms/tare/protocol/openid-connect/certs',
  },
  otel: {
    exporterEndpoint: process.env.OTEL_EXPORTER_OTLP_ENDPOINT || 'http://localhost:4317',
  },
  allbank: {
    webhookIpAllowlist: process.env.ALLBANK_WEBHOOK_IP_ALLOWLIST || '0.0.0.0/0',
    feeBps: parseInt(process.env.ALLBANK_FEE_BPS || '150'),
  },
  splits: {
    tare: 0.20,
    ismc: 0.20,
    cda: 0.14,
    cashlink: 0.45,
    ecommerce_software: 0.01,
  },
} as const;