import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { PaymentService, PaymentRequest, AllBankWebhookPayload } from '../services/payment';

const paymentService = new PaymentService(parseInt(process.env.ALLBANK_FEE_BPS || '150'));

export default async function paymentsRoutes(app: FastifyInstance) {
  // Process payment
  app.post('/payments', async (req, reply) => {
    const body = z.object({
      orderId: z.string(),
      amount: z.number().positive(),
      paymentMethod: z.enum(['credit_card', 'bank_transfer', 'ewallet']),
      customerInfo: z.object({
        name: z.string(),
        email: z.string().email(),
        phone: z.string().optional(),
      }),
    }).parse(req.body);

    const result = await paymentService.processPayment(body as PaymentRequest);
    
    // Log payment transaction
    console.log(`Payment processed: ${result.id} for order ${result.orderId}`);
    
    return reply.header('x-audit-ref', result.auditRef).send(result);
  });

  // AllBank webhook handler
  app.post('/payments/webhook/allbank', async (req, reply) => {
    const payload = z.object({
      transaction_id: z.string(),
      order_id: z.string(),
      amount: z.number(),
      fee: z.number(),
      status: z.enum(['success', 'failed']),
      timestamp: z.string(),
      signature: z.string(),
    }).parse(req.body);

    try {
      await paymentService.processWebhook(payload as AllBankWebhookPayload);
      return reply.send({ success: true });
    } catch (error) {
      app.log.error('Webhook processing failed:', error);
      return reply.code(400).send({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Get payment status
  app.get('/payments/:id', async (req, reply) => {
    const { id } = req.params as any;
    const payment = await paymentService.getPaymentStatus(id);
    
    if (!payment) {
      return reply.code(404).send({ error: 'Payment not found' });
    }
    
    return reply.send(payment);
  });

  // Refund payment
  app.post('/payments/:id/refund', async (req, reply) => {
    const { id } = req.params as any;
    const body = z.object({
      amount: z.number().positive().optional(),
      reason: z.string().optional(),
    }).parse(req.body);

    const refund = await paymentService.refundPayment(id, body.amount);
    
    return reply.header('x-audit-ref', refund.auditRef).send(refund);
  });

  // Get payment methods
  app.get('/payments/methods', async (req, reply) => {
    const methods = [
      { id: 'credit_card', name: 'Credit Card', fee_bps: 150 },
      { id: 'bank_transfer', name: 'Bank Transfer', fee_bps: 150 },
      { id: 'ewallet', name: 'E-Wallet', fee_bps: 150 },
    ];
    
    return reply.send({ methods });
  });

  // Calculate fee
  app.get('/payments/fee/:amount', async (req, reply) => {
    const { amount } = req.params as any;
    const fee = paymentService.calculateFee(parseFloat(amount));
    
    return reply.send({
      amount: parseFloat(amount),
      fee,
      fee_bps: parseInt(process.env.ALLBANK_FEE_BPS || '150'),
      total: parseFloat(amount) + fee,
    });
  });
}