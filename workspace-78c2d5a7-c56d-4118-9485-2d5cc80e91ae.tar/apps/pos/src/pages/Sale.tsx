import { useState } from 'react'
import { Search, Plus, Minus, Trash2, Package } from 'lucide-react'

export default function Sale() {
  const [searchTerm, setSearchTerm] = useState('')
  const [cart, setCart] = useState<any[]>([])
  const [total, setTotal] = useState(0)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">New Sale</h1>
        <p className="mt-1 text-sm text-gray-600">
          Process customer orders and payments
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Product Search */}
        <div className="lg:col-span-2">
          <div className="pos-card p-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pos-input pl-10"
              />
            </div>
          </div>

          {/* Product Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-4">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((item) => (
              <div key={item} className="pos-card p-4 cursor-pointer hover:shadow-md transition-shadow">
                <div className="aspect-square bg-gray-100 rounded-lg mb-3 flex items-center justify-center">
                  <Package className="h-8 w-8 text-gray-400" />
                </div>
                <h4 className="font-medium text-sm">Product {item}</h4>
                <p className="text-lg font-bold text-blue-600">₱{(item * 100 + 50).toLocaleString()}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Shopping Cart */}
        <div className="lg:col-span-1">
          <div className="pos-card p-4">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Shopping Cart</h3>
            
            {cart.length === 0 ? (
              <p className="text-gray-500 text-center py-8">Cart is empty</p>
            ) : (
              <div className="space-y-3">
                {cart.map((item, index) => (
                  <div key={index} className="flex items-center justify-between py-2 border-b">
                    <div className="flex-1">
                      <p className="text-sm font-medium">{item.name}</p>
                      <p className="text-xs text-gray-500">₱{item.price}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button className="p-1 rounded hover:bg-gray-100">
                        <Minus className="h-4 w-4" />
                      </button>
                      <span className="text-sm font-medium">{item.quantity}</span>
                      <button className="p-1 rounded hover:bg-gray-100">
                        <Plus className="h-4 w-4" />
                      </button>
                      <button className="p-1 rounded hover:bg-red-100 text-red-600">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Total */}
            <div className="mt-6 pt-4 border-t">
              <div className="flex justify-between items-center mb-4">
                <span className="text-lg font-medium">Total</span>
                <span className="text-2xl font-bold text-blue-600">₱{total.toLocaleString()}</span>
              </div>
              <button className="pos-button pos-button-primary w-full">
                Process Payment
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}