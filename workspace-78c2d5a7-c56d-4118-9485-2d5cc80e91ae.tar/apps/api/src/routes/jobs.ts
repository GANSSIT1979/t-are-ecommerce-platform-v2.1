import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { ingestPricelist } from '../jobs/ingestPricelist';

export default async function jobsRoutes(app: FastifyInstance) {
  app.post('/jobs/ingest-pricelist', async (req, reply) => {
    const body = z.object({ path: z.string(), dryRun: z.boolean().optional() }).parse(req.body);
    const res = await ingestPricelist(body.path, { dryRun: body.dryRun });
    return reply.header('x-audit-ref', `job-${Date.now()}`).send(res);
  });
}