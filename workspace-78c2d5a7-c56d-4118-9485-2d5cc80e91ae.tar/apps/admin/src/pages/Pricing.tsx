import { useState } from 'react'
import { Calculator } from 'lucide-react'

export default function Pricing() {
  const [skuId, setSkuId] = useState('')
  const [quantity, setQuantity] = useState(1)
  const [uom, setUom] = useState('case')
  const [rebate, setRebate] = useState(0.05)
  const [result, setResult] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  const calculatePricing = async () => {
    setLoading(true)
    try {
      const response = await fetch(`/api/pricing/sku/${skuId}?quantity=${quantity}&uom=${uom}&rebate=${rebate}`)
      const data = await response.json()
      setResult(data)
    } catch (error) {
      console.error('Error calculating pricing:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Pricing Calculator</h1>
        <p className="mt-1 text-sm text-gray-600">
          Calculate pricing with revenue splits for SKUs
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Form */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Calculate Price</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">SKU ID</label>
              <input
                type="text"
                value={skuId}
                onChange={(e) => setSkuId(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                placeholder="e.g., JRNR-12345"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Quantity</label>
              <input
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(parseInt(e.target.value))}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                min="1"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Unit of Measure</label>
              <select
                value={uom}
                onChange={(e) => setUom(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              >
                <option value="piece">Piece</option>
                <option value="inner">Inner</option>
                <option value="case">Case</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Rebate (3-5%)</label>
              <input
                type="number"
                value={rebate}
                onChange={(e) => setRebate(parseFloat(e.target.value))}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                min="0.03"
                max="0.05"
                step="0.01"
              />
            </div>
            <button
              onClick={calculatePricing}
              disabled={loading || !skuId}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
            >
              {loading ? 'Calculating...' : 'Calculate'}
            </button>
          </div>
        </div>

        {/* Results */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Results</h3>
          {result ? (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">SKU ID</p>
                  <p className="font-medium">{result.sku_id}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Status</p>
                  <p className="font-medium">{result.status}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">SRP</p>
                  <p className="font-medium">₱{result.srp}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Price per Piece</p>
                  <p className="font-medium">₱{result.price_per_piece.toFixed(2)}</p>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Revenue Splits</h4>
                <div className="space-y-2">
                  {Object.entries(result.split_amounts).map(([key, value]) => (
                    <div key={key} className="flex justify-between">
                      <span className="text-sm text-gray-600">{key}</span>
                      <span className="text-sm font-medium">₱{Number(value).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>

              {result.warnings && result.warnings.length > 0 && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3">
                  <h4 className="text-sm font-medium text-yellow-800">Warnings</h4>
                  <ul className="mt-1 text-sm text-yellow-700">
                    {result.warnings.map((warning: string, index: number) => (
                      <li key={index}>• {warning}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ) : (
            <p className="text-gray-500 text-center py-8">Enter SKU details and click Calculate</p>
          )}
        </div>
      </div>
    </div>
  )
}