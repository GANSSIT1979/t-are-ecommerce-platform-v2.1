import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { quotePricing } from '../pricing/engine';

const Q = z.object({
  id: z.string(),
  quantity: z.coerce.number().int().positive(),
  uom: z.enum(['piece','inner','case']),
  rebate: z.coerce.number().min(0.03).max(0.05),
});

export default async function pricingRoutes(app: FastifyInstance) {
  app.get('/pricing/sku/:id', async (req, reply) => {
    const { id } = req.params as any;
    const { quantity, uom, rebate } = Q.parse({ id, ...req.query });
    const res = await quotePricing({ skuId: id, quantity, uom, rebate });
    return reply.header('x-audit-ref', res.audit_ref).send(res);
  });
}