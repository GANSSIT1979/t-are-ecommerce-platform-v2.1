import fp from 'fastify-plugin';
import IORedis from 'ioredis';

const redis = new IORedis(process.env.REDIS_URL || 'redis://localhost:6379');

export const idempotencyPlugin = fp(async (app) => {
  app.addHook('preHandler', async (req, reply) => {
    const key = req.headers['idempotency-key'] as string | undefined;
    if (!key) return; // optional per route; enforce where needed
    const scope = `${req.method}:${req.routerPath}:${key}`;
    const set = await redis.set(scope, '1', 'NX', 'EX', 60 * 60);
    if (!set) return reply.code(409).send({ error: 'Idempotency conflict' });
  });
});