export interface QuoteInput {
  skuId: string;
  quantity: number;
  uom: 'piece' | 'inner' | 'case';
  rebate: number; // 0.03 to 0.05
}

export interface QuoteResult {
  sku_id: string;
  status: 'Promo' | 'Base';
  uom: 'piece' | 'inner' | 'case';
  quantity: number;
  srp: number;
  price_case: number;
  uom_piece_per_case: number;
  price_per_piece: number;
  rebate: number;
  effective_cogs: number;
  gmp: number;
  splits: {
    tare: number; ismc: number; cda: number; cashlink: number; ecommerce_software: number;
  };
  split_amounts: {
    tare: number; ismc: number; cda: number; cashlink: number; ecommerce_software: number;
  };
  warnings?: string[];
  audit_ref: string;
}

export type Term = 'POST' | 'COD' | '15D' | '30D';

export interface SupportItem {
  label: string;
  percent: number;
  amount: number;
  booking: string;
}

export interface SupportResult {
  term: Term;
  volume: number;
  items: SupportItem[];
  totalSupportPct: number;
  grandTotalPct: number;
  grandTotalAmount: number;
}

export interface TenantClaims {
  org_id: string;
  coop_id?: string;
  branch_id?: string;
  store_id?: string;
  role: string;
  scopes?: string[];
}