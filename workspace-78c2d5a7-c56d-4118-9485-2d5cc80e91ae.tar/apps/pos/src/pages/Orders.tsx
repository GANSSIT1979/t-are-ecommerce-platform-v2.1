import { ListOrdered } from 'lucide-react'

export default function Orders() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Orders</h1>
        <p className="mt-1 text-sm text-gray-600">
          View and manage order history
        </p>
      </div>

      <div className="pos-card">
        <div className="p-6">
          <p className="text-gray-500 text-center py-8">Order history interface coming soon...</p>
        </div>
      </div>
    </div>
  )
}