import { useState } from 'react'
import { ShoppingCart, TrendingUp, Package, DollarSign } from 'lucide-react'

export default function Dashboard() {
  const [stats] = useState({
    todaySales: 45678,
    todayOrders: 123,
    activeProducts: 456,
    avgOrderValue: 371,
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">POS Dashboard</h1>
        <p className="mt-1 text-sm text-gray-600">
          Welcome to T-ARE Point of Sale System
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="pos-card p-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <DollarSign className="h-8 w-8 text-green-500" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Today's Sales</p>
              <p className="text-lg font-bold text-gray-900">₱{stats.todaySales.toLocaleString()}</p>
            </div>
          </div>
        </div>

        <div className="pos-card p-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <ShoppingCart className="h-8 w-8 text-blue-500" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Today's Orders</p>
              <p className="text-lg font-bold text-gray-900">{stats.todayOrders}</p>
            </div>
          </div>
        </div>

        <div className="pos-card p-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Package className="h-8 w-8 text-purple-500" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Active Products</p>
              <p className="text-lg font-bold text-gray-900">{stats.activeProducts}</p>
            </div>
          </div>
        </div>

        <div className="pos-card p-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <TrendingUp className="h-8 w-8 text-orange-500" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Avg Order Value</p>
              <p className="text-lg font-bold text-gray-900">₱{stats.avgOrderValue}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="pos-card p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <button className="pos-button pos-button-primary w-full">
              Start New Sale
            </button>
            <button className="pos-button pos-button-secondary w-full">
              Add Product
            </button>
            <button className="pos-button pos-button-secondary w-full">
              View Orders
            </button>
          </div>
        </div>

        <div className="pos-card p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Recent Activity</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center py-2 border-b">
              <div>
                <p className="text-sm font-medium">Order #1234</p>
                <p className="text-xs text-gray-500">2 minutes ago</p>
              </div>
              <span className="text-sm font-medium text-green-600">₱1,250</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b">
              <div>
                <p className="text-sm font-medium">Order #1233</p>
                <p className="text-xs text-gray-500">15 minutes ago</p>
              </div>
              <span className="text-sm font-medium text-green-600">₱890</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <div>
                <p className="text-sm font-medium">Order #1232</p>
                <p className="text-xs text-gray-500">1 hour ago</p>
              </div>
              <span className="text-sm font-medium text-green-600">₱2,100</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}