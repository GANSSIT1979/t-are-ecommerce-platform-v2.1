import { pgTable, text, serial, timestamp, numeric, integer, jsonb } from 'drizzle-orm/pg-core';

// Directory
export const orgs = pgTable('orgs', { id: text('id').primaryKey(), name: text('name').notNull() });
export const coops = pgTable('coops', { id: text('id').primaryKey(), org_id: text('org_id').notNull(), name: text('name').notNull() });
export const branches = pgTable('branches', { id: text('id').primaryKey(), org_id: text('org_id').notNull(), coop_id: text('coop_id'), name: text('name').notNull() });
export const stores = pgTable('stores', { id: text('id').primaryKey(), org_id: text('org_id').notNull(), coop_id: text('coop_id'), branch_id: text('branch_id'), name: text('name').notNull() });

// Catalog
export const skus = pgTable('skus', {
  id: text('id').primaryKey(),
  org_id: text('org_id').notNull(),
  name: text('name').notNull(),
  status: text('status').notNull(), // Promo | Base
  sku_type: text('sku_type'),
  uom_piece_per_case: integer('uom_piece_per_case'),
  extras: jsonb('extras'),
});

export const sku_prices = pgTable('sku_prices', {
  id: serial('id').primaryKey(),
  sku_id: text('sku_id').notNull(),
  effective_from: timestamp('effective_from').notNull(),
  price_piece: numeric('price_piece'),
  price_inner: numeric('price_inner'),
  price_case: numeric('price_case'),
  srp: numeric('srp'),
});

export const sku_status_history = pgTable('sku_status_history', {
  id: serial('id').primaryKey(),
  sku_id: text('sku_id').notNull(),
  status: text('status').notNull(),
  at: timestamp('at').defaultNow().notNull(),
});

// Orders/Payments/Finance
export const orders = pgTable('orders', {
  id: text('id').primaryKey(),
  org_id: text('org_id').notNull(),
  coop_id: text('coop_id'),
  branch_id: text('branch_id'),
  store_id: text('store_id'),
  status: text('status').notNull(),
  audit_ref: text('audit_ref').notNull(),
});

export const order_lines = pgTable('order_lines', {
  id: serial('id').primaryKey(), order_id: text('order_id').notNull(), sku_id: text('sku_id').notNull(), qty: integer('qty').notNull(), uom: text('uom').notNull()
});

export const payments = pgTable('payments', {
  id: text('id').primaryKey(), order_id: text('order_id').notNull(), amount: numeric('amount').notNull(), fee_bps: integer('fee_bps').notNull(), status: text('status').notNull()
});

export const transactions = pgTable('transactions', {
  id: serial('id').primaryKey(), payment_id: text('payment_id').notNull(), type: text('type').notNull(), raw: jsonb('raw')
});

export const ledger_entries = pgTable('ledger_entries', {
  id: serial('id').primaryKey(),
  txn_id: text('txn_id').notNull(),
  account: text('account').notNull(),
  debit: numeric('debit').default('0'),
  credit: numeric('credit').default('0'),
  audit_ref: text('audit_ref').notNull(),
});

// Logistics (stubs)
export const dispatches = pgTable('dispatches', { id: text('id').primaryKey(), order_id: text('order_id').notNull(), state: text('state').notNull() });
export const asn = pgTable('asn', { id: text('id').primaryKey(), order_id: text('order_id').notNull() });
export const pod = pgTable('pod', { id: text('id').primaryKey(), order_id: text('order_id').notNull(), url: text('url') });
export const grn = pgTable('grn', { id: text('id').primaryKey(), order_id: text('order_id').notNull() });