import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import POSLayout from './components/POSLayout'
import Dashboard from './pages/Dashboard'
import Sale from './pages/Sale'
import Products from './pages/Products'
import Orders from './pages/Orders'
import Settings from './pages/Settings'

const queryClient = new QueryClient()

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <POSLayout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/sale" element={<Sale />} />
            <Route path="/products" element={<Products />} />
            <Route path="/orders" element={<Orders />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </POSLayout>
      </Router>
    </QueryClientProvider>
  )
}

export default App